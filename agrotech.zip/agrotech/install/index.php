<?php
// Include config file
require_once 'conf.php';
require_once 'createdevice.php';
require_once 'createhistory.php';
require_once 'createsampledata.php';
?>