[
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:22:11",
    "temperature": "27.00",
    "humidity": "27.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:22:23",
    "temperature": "27.00",
    "humidity": "27.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:22:35",
    "temperature": "27.00",
    "humidity": "27.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:22:47",
    "temperature": "27.00",
    "humidity": "27.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:23:00",
    "temperature": "27.00",
    "humidity": "27.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:23:11",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:23:23",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:23:35",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:23:47",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:23:58",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:24:12",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:24:23",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:24:35",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:24:47",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:25:49",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:26:17",
    "temperature": "27.00",
    "humidity": "54.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:26:28",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:26:41",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:26:53",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:27:05",
    "temperature": "27.00",
    "humidity": "51.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:27:50",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:28:03",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:28:16",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:28:28",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:28:39",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:28:51",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:29:19",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:29:31",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:29:43",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:29:55",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:30:07",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:30:18",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:30:30",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:30:42",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:30:54",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:31:05",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:31:17",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:31:29",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:31:41",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:31:52",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:32:04",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:32:16",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:32:44",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:32:55",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:33:07",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:33:35",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:34:20",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:34:32",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:35:00",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:35:12",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:35:23",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:35:35",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:35:47",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:36:17",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:36:28",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:36:40",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:36:52",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:37:04",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:37:16",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:37:29",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:37:41",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:37:52",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:38:04",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:38:16",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:38:27",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:38:39",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:38:51",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:39:20",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:39:32",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:39:43",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:39:55",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:40:07",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:40:35",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:41:03",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:41:15",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:41:27",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:41:39",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:41:50",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:42:02",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:42:14",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:42:26",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:42:37",
    "temperature": "27.00",
    "humidity": "50.00",
    "moisture": "30"
  },
  {
    "devicekey": "agricaltural",
    "time": "2020-02-25 17:42:49",
    "temperature": "27.00",
    "humidity": "49.00",
    "moisture": "30"
  }
]